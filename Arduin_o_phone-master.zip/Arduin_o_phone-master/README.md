# Arduin-o-phone


Apple, Schmapple! Make your own phone with an Arduino & Adafruit FONA shield. This project will show you how you can use the FONA shield and a TFT shield stacked on top to make a touch-screen phone that you can program yourself.

Using Adafruit's great libraries, you can make your own touch-screen dialer in 200 lines of code. Extend it yourself, or keep it simple. Design your own interface or code up a custom app, right from the Arduino IDE. OK sure, you can't check your facebook on the Arduin-o-Phone, but maybe that's not such a bad idea?

Check out more and build it yourself at https://learn.adafruit.com/arduin-o-phone-arduino-powered-diy-cellphone